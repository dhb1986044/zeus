# tests/test_geocoder.py
# 测试/测试地理编码器.py
import unittest
import sys
import os
from unittest.mock import patch, MagicMock

# 将项目根路径添加到 Python 路径，以允许从 geocoding_service 和 config 导入
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, project_root)

from geocoding_service.geocoder import Geocoder
import config

class TestGeocoder(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        """此类中所有测试的设置。"""
        # 如果测试用的虚拟映射文件不存在，则创建它们
        # 以避免在测试期间因真实数据文件丢失或为空而导致的错误。
        cls.test_data_dir = os.path.join(project_root, 'data_test_temp')
        os.makedirs(cls.test_data_dir, exist_ok=True)

        cls.village_mapping_file = os.path.join(cls.test_data_dir, 'village_org_test.csv')
        with open(cls.village_mapping_file, 'w', encoding='utf-8') as f:
            f.write("village_name,organization_code,organization_name\n")
            f.write("测试村A,ORG001,测试机构A\n")
            f.write("测试村B,ORG002,测试机构B\n")

        cls.address_mapping_file = os.path.join(cls.test_data_dir, 'address_org_test.csv')
        with open(cls.address_mapping_file, 'w', encoding='utf-8') as f:
            f.write("address_pattern,organization_code,organization_name\n")
            f.write("*测试街道*,ORG003,测试机构C\n")
            f.write("*测试路*,ORG004,测试机构D\n")

        cls.township_alias_mapping_file = os.path.join(cls.test_data_dir, 'township_alias_test.csv')
        with open(cls.township_alias_mapping_file, 'w', encoding='utf-8') as f:
            f.write("alias,official_name\n")
            f.write("旧镇名称,新镇名称\n")

        cls.aoi_org_mapping_file = os.path.join(cls.test_data_dir, 'aoi_org_test.csv')
        with open(cls.aoi_org_mapping_file, 'w', encoding='utf-8') as f:
            f.write("aoiid,organization_code,organization_name\n")
            f.write("AOI001,ORG_AOI_A,测试AOI机构A\n")
            f.write("AOI002,ORG_AOI_B,测试AOI机构B\n")
        
        # 修补配置以使用这些测试文件
        cls.patch_village_file = patch.object(config, 'VILLAGE_ORG_MAPPING_FILE', cls.village_mapping_file)
        cls.patch_address_file = patch.object(config, 'ADDRESS_ORG_MAPPING_FILE', cls.address_mapping_file)
        cls.patch_township_alias_file = patch.object(config, 'TOWNSHIP_ALIAS_MAPPING_FILE', cls.township_alias_mapping_file)
        cls.patch_aoi_org_file = patch.object(config, 'AOI_ORG_MAPPING_FILE', cls.aoi_org_mapping_file)
        
        cls.patch_village_file.start()
        cls.patch_address_file.start()
        cls.patch_township_alias_file.start()
        cls.patch_aoi_org_file.start()

        # 修补外部地理服务 URL 以避免在测试期间进行实际的 API 调用
        cls.patch_geo_service_url = patch.object(config, 'GEO_SERVICE_API_URL', 'http://fake-geo-service.com/api')
        cls.patch_ab_geo_service_url = patch.object(config, 'AB_GEO_SERVICE_API_URL', 'http://fake-ab-geo-service.com/api')
        cls.patch_geo_service_url.start()
        cls.patch_ab_geo_service_url.start()

        cls.geocoder = Geocoder()

    @classmethod
    def tearDownClass(cls):
        """此类中所有测试完成后的清理。"""
        cls.patch_village_file.stop()
        cls.patch_address_file.stop()
        cls.patch_township_alias_file.stop()
        cls.patch_aoi_org_file.stop()
        cls.patch_geo_service_url.stop()
        cls.patch_ab_geo_service_url.stop()
        
        # 清理虚拟文件和目录
        os.remove(cls.village_mapping_file)
        os.remove(cls.address_mapping_file)
        os.remove(cls.township_alias_mapping_file)
        os.remove(cls.aoi_org_mapping_file)
        os.rmdir(cls.test_data_dir)

    def _mock_external_geo_response(self, status_code=200, json_data=None, exception=None):
        """模拟 requests.get 响应的辅助函数。"""
        mock_resp = MagicMock()
        if exception:
            mock_resp.raise_for_status.side_effect = exception
            return mock_resp
            
        mock_resp.status_code = status_code
        if json_data:
            mock_resp.json.return_value = json_data
        
        if status_code != 200:
            mock_resp.raise_for_status.side_effect = requests.exceptions.HTTPError(f"Mock HTTP Error {status_code}")
        return mock_resp

    @patch('requests.get')
    def test_call_external_geo_service_success(self, mock_get):
        """测试成功调用外部地理服务。"""
        mock_response_data = {
            "status": "success", 
            "formatted_address": "模拟省模拟市模拟区测试村A",
            "province": "模拟省", "city": "模拟市", "district": "模拟区", "village": "测试村A"
        }
        mock_get.return_value = self._mock_external_geo_response(json_data=mock_response_data)
        
        result = self.geocoder.call_external_geo_service("some address")
        self.assertEqual(result, mock_response_data)
        mock_get.assert_called_once_with('http://fake-geo-service.com/api', params={'address': 'some address'}, timeout=10)

    @patch('requests.get')
    def test_call_external_geo_service_failure(self, mock_get):
        """测试调用外部地理服务失败。"""
        mock_get.return_value = self._mock_external_geo_response(status_code=500)
        
        result = self.geocoder.call_external_geo_service("some address")
        self.assertIsNone(result)

    @patch('requests.get')
    def test_call_external_geo_service_request_exception(self, mock_get):
        """测试外部调用期间发生 requests.exceptions.RequestException 的情况。"""
        mock_get.side_effect = requests.exceptions.Timeout("Mock Timeout")
        result = self.geocoder.call_external_geo_service("some address")
        self.assertIsNone(result)

    def test_normalize_address_success(self):
        """测试使用有效的 geo_data 进行地址规范化。"""
        geo_data = {
            "status": "success",
            "province": "模拟省", "city": "模拟市", "district": "模拟区", 
            "township": "模拟镇", "street": "模拟街", "number": "123号", "village": "测试村A"
        }
        expected_normalized = "模拟省模拟市模拟区模拟镇模拟街123号测试村A"
        self.assertEqual(self.geocoder.normalize_address(geo_data), expected_normalized)

    def test_normalize_address_failure(self):
        """测试使用失败的 geo_data 进行地址规范化。"""
        geo_data_fail = {"status": "error"}
        self.assertIn("failed due to geo service error", self.geocoder.normalize_address(geo_data_fail))
        self.assertIn("failed due to geo service error", self.geocoder.normalize_address(None))

    def test_match_organization_by_village(self):
        """测试按村名匹配组织。"""
        geo_data = {"village": "测试村A"}
        expected_org_info = {'organization_code': 'ORG001', 'organization_name': '测试机构A'}
        self.assertEqual(self.geocoder.match_organization(geo_data, "any normalized address"), expected_org_info)

    def test_match_organization_by_address_pattern(self):
        """测试当村庄不匹配时按地址模式匹配组织。"""
        geo_data = {"village": "不存在的村"} # 村庄不匹配
        normalized_address = "某个省某个市某个区测试街道123号"
        expected_org_info = {'organization_code': 'ORG003', 'organization_name': '测试机构C'}
        self.assertEqual(self.geocoder.match_organization(geo_data, normalized_address), expected_org_info)

    def test_match_organization_no_match(self):
        """测试无组织匹配。"""
        geo_data = {"village": "不存在的村"}
        normalized_address = "一个完全不匹配的地址"
        self.assertIsNone(self.geocoder.match_organization(geo_data, normalized_address))

    @patch.object(Geocoder, 'call_external_geo_service')
    def test_geocode_full_flow_village_match(self, mock_call_external):
        """测试主地理编码功能（村庄匹配）。"""
        mock_geo_data = {
            "status": "success", 
            "formatted_address": "模拟省模拟市模拟区测试村A",
            "province": "模拟省", "city": "模拟市", "district": "模拟区", "village": "测试村A"
        }
        mock_call_external.return_value = mock_geo_data
        
        address = "某个地址 测试村A"
        result = self.geocoder.geocode(address)
        
        mock_call_external.assert_called_once_with(address)
        self.assertEqual(result['original_address'], address)
        self.assertEqual(result['normalized_address'], "模拟省模拟市模拟区测试村A")
        self.assertEqual(result['matched_organization'], {'organization_code': 'ORG001', 'organization_name': '测试机构A'})
        self.assertEqual(result['geo_service_response'], mock_geo_data)

    @patch.object(Geocoder, 'call_external_geo_service')
    def test_geocode_full_flow_address_pattern_match(self, mock_call_external):
        """测试主地理编码功能（地址模式匹配）。"""
        mock_geo_data = {
            "status": "success", 
            "formatted_address": "模拟省模拟市模拟区测试街道",
            "province": "模拟省", "city": "模拟市", "district": "模拟区", "township": "测试街道"
            # 没有 'village' 或村庄不匹配
        }
        mock_call_external.return_value = mock_geo_data
        
        address = "模拟省模拟市模拟区测试街道"
        result = self.geocoder.geocode(address)
        
        self.assertEqual(result['matched_organization'], {'organization_code': 'ORG003', 'organization_name': '测试机构C'})

    @patch.object(Geocoder, 'call_external_geo_service')
    def test_geocode_external_service_fails(self, mock_call_external):
        """测试外部服务调用失败时的地理编码。"""
        mock_call_xzqh.return_value = None # XZQH service also fails
        address = "some address"
        result = self.geocoder.geocode(address)
        self.assertIn("Failed to get data from external geo service", result.get('error', ''))

    def test_replace_township_alias(self):
        """测试乡镇别名替换功能。"""
        address_with_alias = "某个省旧镇名称某村"
        expected_address = "某个省新镇名称某村"
        self.assertEqual(self.geocoder.replace_township_alias(address_with_alias), expected_address)

        address_without_alias = "某个省某个镇某村"
        self.assertEqual(self.geocoder.replace_township_alias(address_without_alias), address_without_alias)

    @patch('requests.get')
    def test_call_ab_geo_service_success(self, mock_get):
        """测试成功调用AB地理服务。"""
        mock_response_data = {
            "status": "success", 
            "aoiid": "AOI001",
            "formatted_address": "模拟AB省模拟AB市模拟AB区新镇名称",
            "province": "模拟AB省", "city": "模拟AB市", "district": "模拟AB区", "township": "新镇名称"
        }
        # 模拟对 fake-ab-geo-service.com/api 的调用
        mock_get.return_value = self._mock_external_geo_response(json_data=mock_response_data)
        
        result = self.geocoder.call_ab_geo_service("some address with new township")
        self.assertEqual(result, mock_response_data)
        mock_get.assert_called_once_with('http://fake-ab-geo-service.com/api', params={'address': 'some address with new township'}, timeout=10)

    @patch('requests.get')
    def test_call_ab_geo_service_failure(self, mock_get):
        """测试调用AB地理服务失败。"""
        mock_get.return_value = self._mock_external_geo_response(status_code=500)
        result = self.geocoder.call_ab_geo_service("some address")
        self.assertIsNone(result)

    @patch('requests.get')
    def test_call_ab_geo_service_request_exception(self, mock_get):
        """测试AB地理服务调用期间发生 requests.exceptions.RequestException 的情况。"""
        mock_get.side_effect = requests.exceptions.Timeout("Mock Timeout for AB service")
        result = self.geocoder.call_ab_geo_service("some address")
        self.assertIsNone(result)

    def test_match_organization_by_aoi(self):
        """测试通过AOI ID匹配组织。"""
        aoiid_match = "AOI001"
        expected_org_info = {'organization_code': 'ORG_AOI_A', 'organization_name': '测试AOI机构A'}
        self.assertEqual(self.geocoder.match_organization_by_aoi(aoiid_match), expected_org_info)

        aoiid_no_match = "NON_EXISTENT_AOI"
        self.assertIsNone(self.geocoder.match_organization_by_aoi(aoiid_no_match))
        self.assertIsNone(self.geocoder.match_organization_by_aoi(None))

    @patch.object(Geocoder, 'call_ab_geo_service') # Mock AB service
    @patch.object(Geocoder, 'call_xzqh_geo_service') # Mock original service
    def test_geocode_ab_service_success_aoi_match(self, mock_call_xzqh, mock_call_ab):
        """测试主地理编码功能（AB服务AOI匹配成功）。"""
        address = "某个省的旧镇名称某地"
        # 模拟乡镇替换
        # Geocoder.replace_township_alias 将被内部调用，将 '旧镇名称' 替换为 '新镇名称'
        # 因此，传递给 call_ab_geo_service 的地址将是 "某个省的新镇名称某地"
        
        mock_ab_geo_data = {
            "status": "success", 
            "aoiid": "AOI001",
            "formatted_address": "模拟AB省模拟AB市模拟AB区新镇名称某地",
            "province": "模拟AB省", "city": "模拟AB市", "district": "模拟AB区", "township": "新镇名称"
        }
        mock_call_ab_external.return_value = mock_ab_geo_data
        
        result = self.geocoder.geocode(address)
        
        # 验证 replace_township_alias 的效果反映在对 call_ab_geo_service 的调用中
        mock_call_ab_external.assert_called_once_with("某个省的新镇名称某地")
        mock_call_xzqh.assert_not_called() # Original service should not be called

        self.assertEqual(result['original_address'], address)
        self.assertEqual(result['modified_address_after_alias_replacement'], "某个省的新镇名称某地")
        self.assertEqual(result['normalized_address'], "模拟AB省模拟AB市模拟AB区新镇名称") # 基于 normalize_address 的逻辑
        self.assertEqual(result['matched_organization'], {'organization_code': 'ORG_AOI_A', 'organization_name': '测试AOI机构A'})
        self.assertEqual(result['geo_service_response'], mock_ab_geo_data)
        self.assertEqual(result['source_of_organization_match'], "AB_GEO_SERVICE_AOI")
        self.assertNotIn('error', result)

    @patch.object(Geocoder, 'call_ab_geo_service')
    @patch.object(Geocoder, 'call_xzqh_geo_service')
    def test_geocode_ab_service_fails_fallback_to_xzqh_success(self, mock_call_xzqh, mock_call_ab):
        """测试AB服务失败，回退到原始服务并按村庄匹配。"""
        address = "某个省旧镇名称测试村A"
        # 乡镇替换会发生: "某个省新镇名称测试村A"

        mock_call_ab_external.return_value = None # 模拟AB服务调用失败

        mock_original_geo_data = {
            "status": "success", 
            "formatted_address": "模拟省模拟市模拟区新镇名称测试村A",
            "province": "模拟省", "city": "模拟市", "district": "模拟区", "township": "新镇名称", "village": "测试村A"
        }
        mock_call_external.return_value = mock_original_geo_data
        
        result = self.geocoder.geocode(address)
        
        mock_call_ab_external.assert_called_once_with("某个省新镇名称测试村A")
        mock_call_external.assert_called_once_with("某个省新镇名称测试村A")

        self.assertEqual(result['original_address'], address)
        self.assertEqual(result['modified_address_after_alias_replacement'], "某个省新镇名称测试村A")
        self.assertEqual(result['normalized_address'], "模拟省模拟市模拟区新镇名称测试村A")
        self.assertEqual(result['matched_organization'], {'organization_code': 'ORG001', 'organization_name': '测试机构A'}) # 来自原始村庄匹配
        self.assertEqual(result['geo_service_response'], mock_original_geo_data)
        self.assertEqual(result['source_of_organization_match'], "ORIGINAL_GEO_SERVICE")
        self.assertNotIn('error', result)

    @patch.object(Geocoder, 'call_ab_geo_service')
    @patch.object(Geocoder, 'call_xzqh_geo_service')
    def test_geocode_ab_service_success_no_aoi_match_fallback_to_xzqh_success(self, mock_call_xzqh, mock_call_ab):
        """测试AB服务AOI不匹配，回退到原始服务并按地址模式匹配。"""
        address = "某个省旧镇名称*测试街道*"
        # 乡镇替换: "某个省新镇名称*测试街道*"

        mock_ab_geo_data_no_aoi_match = {
            "status": "success", 
            "aoiid": "NON_EXISTENT_AOI", # AOI存在但无匹配机构
            "formatted_address": "模拟AB省模拟AB市模拟AB区新镇名称某街道",
            "province": "模拟AB省", "city": "模拟AB市", "district": "模拟AB区", "township": "新镇名称"
        }
        mock_call_ab_external.return_value = mock_ab_geo_data_no_aoi_match

        mock_original_geo_data = {
            "status": "success", 
            "formatted_address": "模拟省模拟市模拟区新镇名称测试街道",
            "province": "模拟省", "city": "模拟市", "district": "模拟区", "township": "新镇名称" # 没有村庄
        }
        mock_call_external.return_value = mock_original_geo_data
        
        result = self.geocoder.geocode(address)
        
        mock_call_ab_external.assert_called_once_with("某个省新镇名称*测试街道*")
        mock_call_xzqh.assert_called_once()

        self.assertEqual(result['matched_organization'], {'organization_code': 'ORG003', 'organization_name': '测试机构C'}) # 来自原始地址模式匹配
        self.assertEqual(result['geo_service_response'], mock_original_geo_data) # 应该是原始服务的响应
        self.assertEqual(result['source_of_organization_match'], "ORIGINAL_GEO_SERVICE")
        self.assertNotIn('error', result)

    @patch.object(Geocoder, 'call_ab_geo_service')
    @patch.object(Geocoder, 'call_xzqh_geo_service')
    def test_geocode_both_services_fail(self, mock_call_xzqh, mock_call_ab):
        """测试AB和原始地理服务均失败的情况。"""
        address = "一个注定失败的地址"
        mock_call_ab_external.return_value = None
        mock_call_xzqh.return_value = None # XZQH service also fails

        result = self.geocoder.geocode(address)

        mock_call_ab_external.assert_called_once_with(address) # 假设没有乡镇别名替换
        mock_call_external.assert_called_once_with(address)

        self.assertIsNone(result['matched_organization'])
        self.assertIn("Failed to get data from AB geo service. Also, Failed to get data from XZQH geo service.", result['error'])

if __name__ == '__main__':
    # 这允许直接从此文件运行测试
    # 确保 'requests' 是可导入的，如果测试运行器环境尚未处理
    try:
        import requests
    except ImportError:
        print("如果尚未安装 'requests' (pip install requests)，请安装它以运行这些测试。")
        sys.exit(1)
        
    unittest.main()