# geocoding_service/__init__.py

# This file makes the geocoding_service directory a Python package.
# You can import modules from this package, e.g.:
# from geocoding_service.geocoder import Geocoder

# Optionally, you can define what is exported when using 'from geocoding_service import *'
# __all__ = ['geocoder']