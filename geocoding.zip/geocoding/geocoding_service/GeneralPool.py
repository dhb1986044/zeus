# -*- coding: utf-8 -*-
import socket
import struct
import traceback


class BasePool(object):
    def __init__(self, max_num):
        self.max_num = max_num
        self.obj_list = []
        self.avail_index_list = []

    def init(self, init_func, *init_args):
        self.avail_index_list = list(range(self.max_num))
        self.obj_list = [init_func(*init_args) for _ in range(self.max_num)]

    def get_avail_obj(self):
        while True:
            if self.avail_index_list:
                avail_index = self.avail_index_list.pop()
                return self.obj_list[avail_index], avail_index

    def revert_obj(self, index):
        self.avail_index_list.append(index)

    def reset_obj(self, index, init_func, *init_args):
        obj = self.obj_list[index]
        if obj:
            obj.close()
        self.obj_list[index] = init_func(*init_args)
        self.avail_index_list.append(index)


class TcpPool(BasePool):
    def __init__(self, maxnum):
        super().__init__(maxnum)
        self.host = ''
        self.port = ''

    def connect(self, host, port):
        self.host = host
        self.port = port
        self.init(self.init_sock, *(host, port))

    def request(self, dict_paras, encoding='utf-8'):
        obj, index = self.get_avail_obj()
        res = self.get_result_from_tcp(obj, dict_paras, encoding)
        if not res:
            self.reset_obj(index, self.init_sock, *(self.host, self.port))
        else:
            self.revert_obj(index)
        return res

    def close(self):
        for obj in self.obj_list:
            obj.close()
        self.obj_list = []
        self.avail_index_list = []

    @staticmethod
    def init_sock(host, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(60)

            # 服务验证
            res = sock.connect_ex((host, int(port)))
            if res != 0:
                raise RuntimeError(f'Service is unavailable: {host}:{port}')

            sock.connect((host, int(port)))
            linger_struct = struct.pack('ii', 1, 1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, linger_struct)

            # query = 'ret_splitinfo:2\nuser_id:ronghe\nquery_type:GEOCODE\nfilter_uprecision:2\nopt:ts\naddress:%s\nadcode:%s\noutput:json' % (
            #     '光谷大道金融港', '420100')
            # heade = 0xffffeeee
            # cmdtype = 0
            # length = len(query) + 4
            # q = struct.pack('III%ds' % len(query), heade, length, cmdtype, query.encode('gbk'))
            # sock.send(q)
            # sock.recv(4)
            # length, = struct.unpack('I', sock.recv(4))
            # result = b''
            # remain = length
            # while remain:
            #     t = sock.recv(remain)
            #     result += t
            #     remain -= len(t)

            return sock
        except socket.error as err:
            if isinstance(err, ConnectionRefusedError):
                raise err
            print('socket error!')
            # traceback.print_exc()
        return None

    @staticmethod
    def get_result_from_tcp(sock, dict_paras, encoding):
        try:
            head = 0xffffeeee
            cmdtype = 0
            query = TcpPool.gen_query(dict_paras, encoding)
            length = len(query) + 4
            q = struct.pack('III%ds' % len(query), head, length, cmdtype, query)
            sock.send(q)
            sock.recv(4)
            length, = struct.unpack('I', sock.recv(4))
            result = b''
            remain = length
            while remain:
                t = sock.recv(remain)
                result += t
                remain -= len(t)
            return result
        except Exception as ex:
            # print('request error')
            # traceback.print_exc()
            return b''

    @staticmethod
    def gen_query(dict_paras, encoding):
        return '\n'.join([':'.join((k, str(dict_paras[k]))) for k in dict_paras]).encode(encoding)


if __name__=='__main__':
    cx = TcpPool(1)
    cx.init_sock('10.82.233.50',60188)