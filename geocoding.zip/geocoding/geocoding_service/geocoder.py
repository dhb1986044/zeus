# geocoding_service/geocoder.py
# 编码服务/地理编码器.py
import requests
import logging
from .utils import load_mapping_data
# 假设 config.py 在父目录中并且可以访问
# 如果 main.py 在根目录中，并且它导入了 geocoder，这可能需要调整
# 目前，我们假设如果应用程序从根目录运行，则可以导入 config
import sys
import os
from GeneralPool import tcppool

# 将项目根目录添加到 Python 路径以允许直接导入 config
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, project_root)

import config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Geocoder:
    def __init__(self):
        self.township_alias_mapping = load_mapping_data(config.TOWNSHIP_ALIAS_MAPPING_FILE)
        self.aoi_org_mapping = load_mapping_data(config.AOI_ORG_MAPPING_FILE)
        self.village_org_mapping = load_mapping_data(config.VILLAGE_ORG_MAPPING_FILE)
        self.address_org_mapping = load_mapping_data(config.ADDRESS_ORG_MAPPING_FILE)
        # 在 township_alias_mapping 和 aoi_org_mapping 之上加载的新映射
        logger.info(f"已加载 {len(self.village_org_mapping)} 个村庄-组织映射。")
        logger.info(f"已加载 {len(self.address_org_mapping)} 个地址-组织映射。")
        logger.info(f"已加载 {len(self.township_alias_mapping)} 个乡镇别名映射。")
        logger.info(f"已加载 {len(self.aoi_org_mapping)} 个AOI-组织映射。")

    def call_xzqh_geo_service(self, address):
        """调用外部行政区划地理服务。"""
        params = {
            'address': address,
            # 添加外部 API 所需的其他必要参数
            # 'key': config.GEO_SERVICE_API_KEY # 如果需要 API 密钥
        }
        try:
            # 替换为实际的 API 调用
            # response = requests.get(config.GEO_SERVICE_API_URL, params=params, timeout=10)
            # response.raise_for_status() # 对错误的响应 (4XX 或 5XX) 抛出 HTTPError
            # geo_data = response.json()
            
            # 实际 API 调用的占位符
            logger.info(f"正在为地址调用XZQH地理服务: {address}")
            if config.GEO_SERVICE_API_URL == "YOUR_GEO_SERVICE_API_ENDPOINT_HERE":
                logger.warning("GEO_SERVICE_API_URL未配置。返回模拟数据。")
                # 如果 API 未设置，则为开发提供模拟响应
                return {
                    "status": "success",
                    "formatted_address": f"规范化_{address}",
                    "province": "模拟省",
                    "city": "模拟市",
                    "district": "模拟区",
                    "town": "模拟镇",
                    "village": "模拟村A" # 确保这与 CSV 文件中的某个键匹配以进行测试
                }
            # 使用 TCP 连接池发送请求
            try:
                from GeneralPool import TcpPool
                request_data = {
                    "user_id": "ronghe",
                    "query_type": "GEOCODE",
                    "adcode": "421115",
                    "address": address,
                    "ret_splitinfo": 2,
                    "filter_uprecision": 2,
                    "output": "json"
                }
                sock_pool = TcpPool(1)
                sock_pool.connect(self.host, self.port)
                response_data = sock_pool.request(request_data)
                if not response_data:
                    raise Exception("TCP请求返回为空")
                geo_data = json.loads(response_data)
                logger.info(f"通过TCP连接池获取到地理编码数据: {geo_data}")
                return geo_data
            except Exception as e:
                logger.error(f"TCP请求失败: {e}")
                raise
            
            # response = requests.get(config.GEO_SERVICE_API_URL, params=params, timeout=10)
            # response.raise_for_status()
            # geo_data = response.json()
            # logger.info(f"收到地理编码数据: {geo_data}")
            # return geo_data
        except requests.exceptions.RequestException as e:
            logger.error(f"调用XZQH地理服务时出错: {e}")
            return None
        except Exception as e:
            logger.error(f"调用XZQH地理服务时发生意外错误: {e}")
            return None

    def normalize_address(self, geo_data):
        """根据地理服务的响应规范化地址。"""
        if not geo_data or geo_data.get('status') != 'success':
            return "由于地理服务错误或无数据，地址规范化失败。"
        
        # 规范化示例：连接组件
        # 这在很大程度上取决于 geo_data 的结构
        # formatted_address = geo_data.get('formatted_address')
        # if formatted_address:
        #     return formatted_address
        
        # 如果 'formatted_address' 不存在或需要手动构建，则使用回退方案
        parts = [
            geo_data.get('province', ''),
            geo_data.get('city', ''),
            geo_data.get('district', ''),
            geo_data.get('township', ''), # 或 'town'
            geo_data.get('street', ''),
            geo_data.get('number', ''),
            geo_data.get('village', '')
        ]
        normalized = "".join(filter(None, parts)) # 连接非空部分
        logger.info(f"规范化地址: {normalized}")
        return normalized if normalized else "无法从地理编码数据规范化地址。"

    def match_organization(self, geo_data, normalized_address):
        """使用映射表将地址匹配到组织。"""
        if not geo_data:
            return None

        # 1. 尝试按村名匹配
        village_name = geo_data.get('village')
        if village_name and village_name in self.village_org_mapping:
            org_info = self.village_org_mapping[village_name]
            logger.info(f"通过村名'{village_name}'匹配到组织: {org_info}")
            return org_info

        # 2. 尝试按地址模式匹配（更复杂）
        # 这需要更复杂的模式匹配逻辑
        # 为简单起见，我们在这里进行基本的子字符串检查，但在实际场景中，
        # 您可能会使用正则表达式或其他字符串匹配库。
        for pattern, org_info in self.address_org_mapping.items():
            # CSV 中的 'pattern' 是一个键，org_info 是其他列的字典
            # 假设模式是一个简单的字符串，用于检查是否包含
            # 实际实现可能会使用模式列中的正则表达式
            if pattern.lower() in normalized_address.lower(): # 简单子字符串匹配
                logger.info(f"通过地址模式'{pattern}'匹配到组织: {org_info}")
                return org_info
        
        logger.info(f"未找到匹配的组织，地址: {normalized_address}")
        return None

    def replace_township_alias(self, address):
        """使用乡镇别名表替换地址中的乡镇名称。"""
        modified_address = address
        # 假设 township_alias_mapping 的 CSV 文件第一列是别名 (key),
        # 后续列是值，其中一个列是官方名称。
        # 例如 CSV: alias,official_town_name
        # load_mapping_data 会将 'alias' 作为键，{'official_town_name': '官方名称'} 作为值
        for alias, mapping_values in self.township_alias_mapping.items():
            # 我们需要找到官方名称。假设官方名称的列名是 'official_name' 或类似。
            official_name = mapping_values.get('official_name') # 尝试 'official_name'
            if not official_name: # 如果没有 'official_name' 列，尝试取第一个值
                if mapping_values and isinstance(mapping_values, dict) and len(mapping_values) > 0:
                    official_name = next(iter(mapping_values.values()))

            if official_name and alias in modified_address:
                modified_address = modified_address.replace(alias, official_name)
                logger.info(f"在地址中将乡镇别名'{alias}'替换为'{official_name}'。新地址: {modified_address}")
        return modified_address

    def call_ab_geo_service(self, address):
        """调用AB映射版本的外部地理服务。"""
        params = {'address': address}
        try:
            logger.info(f"正在为地址调用AB地理服务: {address}，URL: {config.AB_GEO_SERVICE_API_URL}")
            if config.AB_GEO_SERVICE_API_URL == "YOUR_AB_GEO_SERVICE_API_ENDPOINT_HERE" or \
               not config.AB_GEO_SERVICE_API_URL:
                logger.warning("AB_GEO_SERVICE_API_URL未配置或是占位符。返回AB服务的模拟数据。")
                # 为开发提供模拟响应，确保包含 aoiid
                return {
                    "status": "success",
                    "aoiid": "mock_aoi_123", # 示例 AOI ID
                    "formatted_address": f"ab_normalized_{address}",
                    "province": "模拟AB省", "city": "模拟AB市",
                    "district": "模拟AB区", "township": "模拟AB镇"
                }
            
            response = requests.get(config.AB_GEO_SERVICE_API_URL, params=params, timeout=10)
            response.raise_for_status()
            ab_geo_data = response.json()
            logger.info(f"收到AB地理编码数据: {ab_geo_data}")
            return ab_geo_data
        except requests.exceptions.RequestException as e:
            logger.error(f"调用AB地理服务时出错: {e}")
            return None
        except Exception as e:
            logger.error(f"调用AB地理服务时发生意外错误: {e}")
            return None

    def match_organization_by_aoi(self, aoiid):
        """使用 AOI-机构映射表通过 AOI ID 匹配组织。"""
        if not aoiid:
            return None
        
        # aoi_org_mapping 的键是 aoiid (假设来自CSV的第一列)
        # 值是包含组织代码和名称的字典
        if aoiid in self.aoi_org_mapping:
            org_info = self.aoi_org_mapping[aoiid]
            logger.info(f"通过AOI ID '{aoiid}'匹配到组织: {org_info}")
            return org_info
        
        logger.info(f"未找到匹配的组织，AOI ID: {aoiid}")
        return None

    def geocode(self, address):
        """主要地理编码功能。"""
        logger.info(f"开始对地址进行地理编码: {address}")

        modified_address = self.replace_township_alias(address)
        
        organization_info = None
        geo_service_response = None 
        normalized_address_str = "规范化失败或不适用。"
        error_message = None
        source_of_org_match = None

        logger.info(f"尝试使用XZQH地理服务对地址进行地理编码: {modified_address}")
        original_geo_data = self.call_xzqh_geo_service(modified_address)

        if original_geo_data:
            geo_service_response = original_geo_data # 暂时设置为响应
            if original_geo_data.get('status') == 'success':
                normalized_address_str = self.normalize_address(original_geo_data)
                organization_info = self.match_organization(original_geo_data, normalized_address_str)
                if organization_info:
                    logger.info("使用XZQH地理服务成功匹配到组织。")
                    source_of_org_match = "XZQH_GEO_SERVICE"
                else:
                    logger.info("XZQH地理服务调用成功但通过村庄/地址未匹配到组织。")
            else: # XZQH服务调用但状态不是'success'
                error_message = f"XZQH地理服务返回状态: {original_geo_data.get('status')}。"
                logger.info(error_message)
        else: # XZQH服务调用本身失败（如超时、网络错误）
            error_message = "从XZQH地理服务获取数据失败。"
            logger.info(error_message)

        # 如果XZQH服务路径未能匹配到组织，尝试AB地理服务
        if not organization_info:
            logger.info("XZQH地理服务路径未能匹配到组织或XZQH服务失败。尝试使用AB地理服务。")
            
            ab_geo_data = self.call_ab_geo_service(modified_address)

            if ab_geo_data:
                geo_service_response = ab_geo_data 
                if ab_geo_data.get('status') == 'success':
                    normalized_address_str = self.normalize_address(ab_geo_data) # 从AB规范化
                    aoiid = ab_geo_data.get('aoiid')
                    if aoiid:
                        organization_info = self.match_organization_by_aoi(aoiid)
                        if organization_info:
                            logger.info(f"使用AB地理服务和AOI ID {aoiid}成功匹配到组织。")
                            source_of_org_match = "AB_GEO_SERVICE_AOI"
                            error_message = None # 如果AB路径成功找到组织，清除之前的XZQH错误
                        else:
                            logger.info(f"AB地理服务提供了AOI ID {aoiid}，但未匹配到组织。")
                    else:
                        logger.info("AB地理服务调用成功但未返回'aoiid'。")
                else: # AB服务调用但状态不是'success'
                    current_ab_error = f"AB地理服务返回状态: {ab_geo_data.get('status')}。"
                    error_message = (error_message + " 另外，" + current_ab_error if error_message else current_ab_error)
                    logger.info(current_ab_error)
            else: # AB服务调用本身失败
                current_ab_error = "从AB地理服务获取数据失败。"
                error_message = (error_message + " 另外，" + current_ab_error if error_message else current_ab_error)
                logger.info(current_ab_error)
        
        # 最终结果组装
        result = {
            "original_address": address,
            "modified_address_after_alias_replacement": modified_address,
            "normalized_address": normalized_address_str,
            "geo_service_response": geo_service_response,
            "matched_organization": organization_info,
            "source_of_organization_match": source_of_org_match
        }
        
        if error_message and not organization_info: # 仅在未找到组织的情况下添加错误
            result["error"] = error_message
            
        logger.info(f"地理编码结果: {result}")
        return result

# 示例用法（用于测试目的）
if __name__ == '__main__':
    # 这假设 config.py 已正确设置，并且映射文件存在于 ../data/ 中
    # 并且此脚本从 geocoding_service 目录或项目根目录运行
    # （如果需要，进行适当的 PYTHONPATH 调整）。
    
    # 确保此测试的配置值不是占位符
    if config.GEO_SERVICE_API_URL == "YOUR_GEO_SERVICE_API_ENDPOINT_HERE":
        print("警告: GEO_SERVICE_API_URL是占位符。外部API调用将使用模拟数据。")

    geocoder = Geocoder()
    
    test_address_1 = "北京市海淀区中关村"
    result_1 = geocoder.geocode(test_address_1)
    print(f"\n地址'{test_address_1}'的地理编码结果:")
    import json
    print(json.dumps(result_1, indent=2, ensure_ascii=False))

    # 使用可能匹配村庄的地址进行测试
    # （假设 '模拟村A' 在 village_organization_mapping.csv 中）
    test_address_2 = "某个地方模拟村A"
    result_2 = geocoder.geocode(test_address_2)
    print(f"\n地址'{test_address_2}'的地理编码结果:")
    print(json.dumps(result_2, indent=2, ensure_ascii=False))

    # 使用可能匹配地址模式的地址进行测试
    # （假设像 '*省*市*区*街道*' 这样的模式在 address_organization_mapping.csv 中）
    test_address_3 = "广东省深圳市南山区科技园街道"
    result_3 = geocoder.geocode(test_address_3)
    print(f"\n地址'{test_address_3}'的地理编码结果:")
    print(json.dumps(result_3, indent=2, ensure_ascii=False))