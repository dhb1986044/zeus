# geocoding_service/utils.py
# 编码服务/工具.py
import csv
import os

def load_mapping_data(file_path):
    """从 CSV 文件加载映射数据。"""
    mapping = {}
    if not os.path.exists(file_path):
        print(f"Warning: Mapping file not found at {file_path}")
        return mapping
    
    try:
        with open(file_path, mode='r', encoding='utf-8') as infile:
            reader = csv.DictReader(infile)
            for row in reader:
                # 假设第一列是键，其余列是值
                # 这可能需要根据实际 CSV 结构进行调整
                key = row[reader.fieldnames[0]]
                mapping[key] = {k: v for k, v in row.items() if k != reader.fieldnames[0]}
    except Exception as e:
        print(f"Error loading mapping file {file_path}: {e}")
    return mapping

# 示例用法（可以删除或修改）：
if __name__ == '__main__':
    # 测试加载 - 假设脚本从项目根目录运行
    # 或路径已相应调整。
    # 这仅用于测试实用程序功能。
    dir_path = os.path.dirname(os.path.realpath(__file__))
    project_root = os.path.abspath(os.path.join(dir_path, '..')) # 从 geocoding_service 向上移动一级
    
    village_map_path = os.path.join(project_root, 'data', 'village_organization_mapping.csv')
    address_map_path = os.path.join(project_root, 'data', 'address_organization_mapping.csv')

    village_data = load_mapping_data(village_map_path)
    print(f"Loaded village mapping data: {village_data}")

    address_data = load_mapping_data(address_map_path)
    print(f"Loaded address mapping data: {address_data}")