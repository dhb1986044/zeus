# 物流地理编码服务

本项目是一个Python服务工程，提供物流版本的地理编码服务，支持多种地理服务调用、地址规范化、乡镇别名替换、AB服务与AOI映射等功能。

## 功能

1.  **调用行政区划地理服务（XZQH）**：与外部行政区划Geo服务接口对接，获取标准化地理信息。
2.  **调用AB地理服务**：支持AB服务调用，获取AOI信息并通过AOI映射表匹配组织。
3.  **地址规范化**：根据地理服务返回结果，对地址进行标准化处理。
4.  **乡镇别名替换**：自动将地址中的乡镇别名替换为官方名称，提升匹配准确率。
5.  **数据匹配**：
    *   匹配乡村-机构映射表
    *   匹配地址-机构映射表
    *   匹配AOI-机构映射表（AB服务）

## 项目结构

```
geocoding/
├── data/ # 存放映射表等数据文件
│   ├── village_organization_mapping.csv      # 村-机构映射
│   ├── address_organization_mapping.csv      # 地址-机构映射
│   ├── township_alias_mapping.csv            # 乡镇别名映射
│   └── aoi_org_mapping.csv                   # AOI-机构映射
├── geocoding_service/ # 核心地理编码服务逻辑
│   ├── __init__.py
│   ├── geocoder.py    # 地理编码器实现
│   └── utils.py       # 工具函数
├── tests/           # 单元测试
│   ├── __init__.py
│   └── test_geocoder.py
├── main.py          # 服务入口点 (Flask应用)
├── config.py        # 配置文件
├── requirements.txt # 项目依赖
└── README.md        # 项目说明
```

## 如何运行

1.  安装依赖：
    ```bash
    pip install -r requirements.txt
    ```
2.  配置服务 (编辑 `config.py`，配置各类映射表路径和外部服务URL)。
3.  运行服务：
    ```bash
    python main.py
    ```

## API 端点

*   `POST /geocode`
    *   请求体: `{"address": "北京市海淀区中关村"}`
    *   响应: 
        ```json
        {
          "original_address": "北京市海淀区中关村",
          "modified_address_after_alias_replacement": "北京市海淀区中关村",
          "normalized_address": "北京市海淀区中关村",
          "geo_service_response": {...},
          "matched_organization": {"organization_code": "...", "organization_name": "..."},
          "source_of_organization_match": "XZQH_GEO_SERVICE | AB_GEO_SERVICE_AOI",
          "error": "..." // 可选
        }
        ```

## 调用流程说明

1. 地址请求进入后，先进行乡镇别名替换。
2. 优先调用XZQH地理服务，尝试通过村名或地址模式匹配组织。
3. 若未匹配到组织，则调用AB地理服务，通过AOI ID匹配组织。
4. 返回标准化地址、匹配到的组织信息及原始地理服务响应。

## 配置说明（config.py）

- `VILLAGE_ORG_MAPPING_FILE`：村-机构映射表路径
- `ADDRESS_ORG_MAPPING_FILE`：地址-机构映射表路径
- `TOWNSHIP_ALIAS_MAPPING_FILE`：乡镇别名映射表路径
- `AOI_ORG_MAPPING_FILE`：AOI-机构映射表路径
- `GEO_SERVICE_API_URL`：行政区划地理服务URL
- `AB_GEO_SERVICE_API_URL`：AB地理服务URL

## 数据表结构说明

- **village_organization_mapping.csv**
    - `village_name,organization_code,organization_name`
- **address_organization_mapping.csv**
    - `address_pattern,organization_code,organization_name`
- **township_alias_mapping.csv**
    - `alias,official_name`
- **aoi_org_mapping.csv**
    - `aoiid,organization_code,organization_name`

## 单元测试

运行 `tests/test_geocoder.py` 可验证各主要功能和流程。

---
如需详细接口文档或有定制需求，请联系开发者。