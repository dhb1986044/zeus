# main.py
# 主程序.py
from flask import Flask, request, jsonify
from geocoding_service.geocoder import Geocoder
import config
import logging

app = Flask(__name__)

# 配置日志记录以匹配 geocoder.py 或更全面
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 初始化地理编码器实例
try:
    geocoder = Geocoder()
    logger.info("Geocoder initialized successfully.")
except Exception as e:
    logger.error(f"Failed to initialize Geocoder: {e}", exc_info=True)
    # 根据期望的行为，您可能希望退出或以有限的功能运行
    # 目前，如果 geocoder 为 None，我们将让它在请求时可能失败
    geocoder = None 

@app.route('/geocode', methods=['POST'])
def handle_geocode():
    if not geocoder:
        logger.error("Geocoder is not available. Initialization might have failed.")
        return jsonify({"error": "Service unavailable, geocoder not initialized."}), 503

    if not request.is_json:
        logger.warning("Request is not JSON.")
        return jsonify({"error": "Request must be JSON"}), 400

    data = request.get_json()
    address = data.get('address')

    if not address:
        logger.warning("Address not provided in request.")
        return jsonify({"error": "'address' field is required"}), 400

    logger.info(f"Received geocoding request for address: {address}")
    try:
        result = geocoder.geocode(address)
        logger.info(f"Successfully geocoded address '{address}'.")
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error during geocoding process for address '{address}': {e}", exc_info=True)
        return jsonify({"error": "An internal error occurred during geocoding."}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """一个简单的健康检查端点。"""
    if geocoder:
        return jsonify({"status": "ok", "message": "Geocoder service is running."}), 200
    else:
        return jsonify({"status": "error", "message": "Geocoder service is not initialized."}), 503

if __name__ == '__main__':
    logger.info(f"Starting Flask development server on {config.HOST}:{config.PORT}")
    # 确保使用 host='0.0.0.0' 以便在需要时可以从外部访问
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)