# config.py

# 外部行政区划地理服务配置
GEO_SERVICE_API_URL = "YOUR_GEO_SERVICE_API_ENDPOINT_HERE" # 请替换为实际的API端点
GEO_SERVICE_API_KEY = "YOUR_GEO_SERVICE_API_KEY_HERE"   # 如果需要API密钥，请配置

# 数据文件路径
VILLAGE_ORG_MAPPING_FILE = "data/village_organization_mapping.csv"
ADDRESS_ORG_MAPPING_FILE = "data/address_organization_mapping.csv"

# 服务配置
HOST = "0.0.0.0"
PORT = 5000
DEBUG = True

# 乡镇别名映射文件路径
TOWNSHIP_ALIAS_MAPPING_FILE = "data/township_alias_mapping.csv"

# AB版本地理编码服务配置
AB_GEO_SERVICE_API_URL = "YOUR_AB_GEO_SERVICE_API_ENDPOINT_HERE"  # 请替换为实际的AB版本API端点

# AOI与机构映射文件路径
AOI_ORG_MAPPING_FILE = "data/aoi_organization_mapping.csv"

# 其他配置项可以根据需要添加